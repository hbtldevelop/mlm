import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Text,
} from "react-native";
import axios from "axios";
import { useUserContext } from "./UserContext";

const Order = ({ navigation }) => {
  const [orders, setOrders] = useState([]);
  const { token } = useUserContext();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get(
          "https://apiv2.shiprocket.in/v1/external/orders",
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        setOrders(response.data.data);
        console.log("Orders:", orders[0]);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    fetchOrders();
  }, [token]);

  const handleTrackOrder = (shipmentId) => {
    navigation.navigate("TrackOrder", { shipmentId });
  };
  const getStatusText = (statusCode) => {
    switch (statusCode) {
      case 6:
        return "Shipped";
      case 7:
        return "Delivered";
      case 8:
        return "Canceled";
      case 9:
        return "RTO Initiated";
      case 10:
        return "RTO Delivered";
      case 12:
        return "Lost";
      case 13:
        return "Pickup Error";
      case 14:
        return "RTO Acknowledged";
      case 15:
        return "Pickup Rescheduled";
      case 16:
        return "Cancellation Requested";
      case 17:
        return "Out For Delivery";
      case 18:
        return "In Transit";
      case 19:
        return "Out For Pickup";
      case 20:
        return "Pickup Exception";
      case 21:
        return "Undelivered";
      case 22:
        return "Delayed";
      case 23:
        return "Partial Delivered";
      case 24:
        return "DESTROYED";
      case 25:
        return "DAMAGED";
      case 26:
        return "FULFILLED";
      case 27:
        return "Pickup Booked";
      // Add more cases for other status codes as needed
      default:
        return "Unknown";
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.orderList}>
          {console.log("Orders:", orders)}
          {orders.map((order) => (
            <View key={order.shipment_id} style={styles.orderItem}>
              <Image
                style={styles.orderImage}
                source={{ uri: order.products[0].image_url }}
              />
              <View style={styles.orderDetails}>
                <Text style={styles.orderTitle}>
                  Shipment ID: {order.channel_order_id}
                </Text>
                <Text style={styles.trackingDetail}>
                  Status: {getStatusText(order.status)}
                </Text>

                <Text style={styles.orderPrice}>Total: ₹{order.total}</Text>
                <TouchableOpacity
                  style={styles.trackOrderButton}
                  onPress={() => handleTrackOrder(order.channel_order_id)}
                >
                  <Text style={styles.trackOrderButtonText}>Track Order</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  orderList: {
    padding: 20,
  },
  orderItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 10,
  },
  orderImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 20,
  },
  orderDetails: {
    flex: 1,
  },
  orderTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 5,
  },
  orderStatus: {
    fontSize: 12,
    marginBottom: 5,
  },
  orderPrice: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  trackOrderButton: {
    backgroundColor: "#1977F3",
    borderRadius: 8,
    padding: 8,
    marginTop: 5,
    alignItems: "center",
  },
  trackOrderButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});

export default Order;
