import { createContext, useContext, useState, useEffect } from "react";

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [userID, setUserID] = useState("");
  const BASE_URL = `https://mlm-temp-server.anujs.dev`;
  const SHIPROCKET = `https://apiv2.shiprocket.in/v1/external/auth/login`;
  const [login, setLogin] = useState(false);
  const [token, setToken] = useState(null);

  const updateUserID = (newUserID) => {
    setUserID(newUserID);
  };

  const loginToShiprocket = async () => {
    const apiUrl = SHIPROCKET;
    const headers = {
      "Content-Type": "application/json",
    };
    const body = {
      email: "hbtl@gmail.com",
      password: "HBTL@123",
    };

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setToken(data.token); // Set the token here
      console.log("Token:", data.token);
    } catch (error) {
      console.error("Error logging in:", error);
    }
  };
  useEffect(() => {
    loginToShiprocket();
  }, []);

  return (
    <UserContext.Provider
      value={{ userID, updateUserID, BASE_URL, login, setLogin, token }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUserContext = () => {
  return useContext(UserContext);
};
