import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Text,
} from "react-native";
import axios from "axios";
import rect from "../Streetmall/Orderstatement/rect.png";
import BottomBar from "./BottomBar";
const logo = require("../assets/streetmalllogo.png");
import { useUserContext } from "./UserContext";

// Status code mapping
const statusMapping = {
  6: "Shipped",
  7: "Delivered",
  8: "Canceled",
  9: "RTO Initiated",
  10: "RTO Delivered",
  // Add more status codes here as needed
};

const OrderTrackingPage = ({ navigation }) => {
  const [trackingData, setTrackingData] = useState(null);
  const { userID, BASE_URL, token } = useUserContext();
  const { shipment_id } = route.params;
  useEffect(() => {
    console.log("Token:", token);
    console.log("Shipment ID:", shipment_id);
    fetchTrackingData();
  }, []);

  const fetchTrackingData = async () => {
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const response = await axios.get(
        "https://apiv2.shiprocket.in/v1/external/courier/track/shipment/{shipment_id}",
        config
      );

      console.log("Tracking data response:", response.data); // Log response data
      setTrackingData(response.data);
    } catch (error) {
      console.error("Error fetching tracking data:", error);
    }
  };
  useEffect(() => {
    console.log("Fetchtrack details", fetchTrackingData);
  });

  const getStatusDescription = (statusCode) => {
    return statusMapping[statusCode] || "Unknown";
  };

  const renderStatus = (status) => {
    return (
      <Text key={status.id}>
        Status: {getStatusDescription(status.track_status)}
      </Text>
    );
  };

  const goToHomePage = () => {
    // Implement navigation to home page here
    // For example: navigation.navigate("Home");
  };

  return (
    <View style={styles.containerw}>
      <ScrollView
        style={styles.containerw}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.container}>
          <Image source={logo} style={styles.logo} />
        </View>

        <Text> {"\n"} </Text>

        <Text style={styles.chtext}>
          *Check your registered email & Mobile number for Invoice
        </Text>
        <Image source={rect} style={styles.claimimg} />
        <Text style={styles.heading}>{"\n"}</Text>
        <Text style={styles.heading}>Track Order Details</Text>
        <View style={styles.orderStatusContainer}>
          {Array.isArray(trackingData) &&
            trackingData.map((item, index) => (
              <View key={index} style={styles.statusItem}>
                <View style={styles.statusIconContainer}>
                  {item.tracking_data.shipment_track[0].current_status ===
                  "PICKED UP" ? (
                    <Image
                      source={require("../Streetmall/Orderstatement/finish.png")}
                      style={styles.statusIcon}
                    />
                  ) : (
                    <Image
                      source={require("../Streetmall/Orderstatement/pending.png")}
                      style={styles.statusIcon}
                    />
                  )}
                </View>
                <View style={styles.statusTextContainer}>
                  <Text style={styles.statusText}>
                    {item.tracking_data.shipment_track[0].current_status}
                  </Text>
                  <Text style={styles.statusDate}>
                    {item.tracking_data.shipment_track[0].edd}
                  </Text>
                </View>
              </View>
            ))}
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.proceedButton} onPress={goToHomePage}>
            <Text style={styles.buttonText}>Home</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.heading}>{"\n"}</Text>
        <Text style={styles.heading}>{"\n"}</Text>
        <Text> {"\n"} </Text>
        <Text> {"\n"} </Text>
      </ScrollView>
      <BottomBar navigation={navigation} />
      <View style={styles.blueBar}></View>
    </View>
  );
};

const styles = StyleSheet.create({
  containerw: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  logo: {
    display: "flex",
    height: 80,
    width: 80,
    alignSelf: "center",
    marginTop: -50,
    marginBottom: 20,
  },
  blueBar: {
    backgroundColor: "#1977F3",
    height: 15,
    position: "absolute",
    bottom: 60,
    left: 0,
    right: 0,
  },
  container: {
    paddingTop: 100,
    backgroundColor: "#1977F3",
    paddingBottom: 15,
  },
  heading: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 8,
    alignSelf: "center",
  },
  topbarinput: {
    justifyContent: "center",
    marginHorizontal: 20,
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    padding: 10,
  },
  inputBox: {
    flex: 1,
    color: "#1977F3",
    marginLeft: 10,
  },
  trackbar: {
    alignSelf: "center",
    aspectRatio: 9,
    resizeMode: "contain",
  },
  buttonContainer: {
    marginTop: 16,
  },
  header: {
    backgroundColor: "#1977F3",
    padding: 20,
    alignItems: "center",
  },
  headerText: {
    color: "white",
    fontSize: 20,
    fontWeight: "bold",
  },
  orderStatusContainer: {
    padding: 20,
  },
  statusItem: {
    flexDirection: "row",
    marginBottom: 20,
  },
  statusIconContainer: {
    marginRight: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  statusIcon: {
    width: 30,
    height: 30,
    resizeMode: "contain",
  },
  statusTextContainer: {
    flex: 1,
  },
  statusText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  statusDate: {
    fontSize: 14,
    color: "#888888",
  },
  claimimg: {
    width: "60%",
    height: "2%",
  },
  chtext: {
    alignSelf: "center",
    color: "#C80000",
    paddingBottom: 30,
  },
  cont: {
    flex: 1,
    padding: 20,
    backgroundColor: "#ffffff",
  },
  productContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 10,
    marginBottom: 20,
  },
  leftContainer: {
    width: "40%",
    alignItems: "center",
  },
  rightContainer: {
    width: "60%",
    marginLeft: 10,
  },
  productImage: {
    width: "100%",
    height: 130,
    resizeMode: "cover",
    borderRadius: 8,
  },
  productName: {
    fontSize: 15,
    fontWeight: "500",
  },
  productDetailoffcont: {
    backgroundColor: "#871818",
    borderRadius: 14,
    padding: 2,
    marginTop: 5,
    width: "25%",
  },
  productDetailoff: {
    color: "white",
    fontSize: 9,
    alignSelf: "center",
    fontWeight: "bold",
  },
  productDetailpri: {
    fontSize: 23,
    fontWeight: "bold",
  },
  productDetaildel: {
    fontSize: 10,
    marginTop: 3,
    color: "blue",
  },
  productDetailst: {
    fontSize: 11,
    marginTop: 5,
    fontWeight: "800",
    color: "brown",
  },
  productCountContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
    borderRadius: 40,
    backgroundColor: "#FFAC2F",
  },
  countButton: {
    width: "30%",
    backgroundColor: "#E0DCDC",
    borderRadius: 30,
    padding: 5,
    marginLeft: 5,
    alignItems: "center",
  },
  deleteButton: {
    width: "30%",
    backgroundColor: "#E0DCDC",
    borderRadius: 30,
    padding: 5,
    alignItems: "center",
  },
  productCountText: {
    fontSize: 18,
    fontWeight: "bold",
    marginHorizontal: 5,
  },
  sbuttonText: {
    color: "black",
    fontWeight: "bold",
    fontSize: 16,
  },
  lstimage: {
    alignSelf: "center",
  },
  chtext: {
    alignSelf: "center",
    color: "#C80000",
    paddingBottom: 60,
  },
  trackbar: {
    alignSelf: "center",
    aspectRatio: 2.9,
    resizeMode: "contain",
  },
  trackcont: {
    flexDirection: "row",
    alignSelf: "center",
  },
  tracktext: {
    fontSize: 13,
    fontWeight: "bold",
    color: "#003478",
    marginLeft: 27,
    marginRight: 10,
  },
  tracktext1: {
    fontSize: 13,
    fontWeight: "bold",
    color: "#003478",
    marginLeft: 20,
    marginRight: 20,
  },
  buttonContainer: {
    marginTop: 16,
    width: "70%",
    alignSelf: "center",
  },
  proceedButton: {
    backgroundColor: "#FF9900",
    borderRadius: 16,
    padding: 13,
    alignItems: "center",
    marginTop: 8,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 17,
  },
});

export default OrderTrackingPage;
