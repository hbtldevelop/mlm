import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { useUserContext } from "./UserContext";

const ForgetPassword = ({ navigation }) => {
  const { userID, BASE_URL } = useUserContext();
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleResetPassword = async () => {
    try {
      if (newPassword !== confirmPassword) {
        setErrorMessage("Passwords do not match");
        setTimeout(() => {
          setErrorMessage("");
        }, 3000);
        return;
      }

      const response = await axios.post(`${BASE_URL}/api/resetPass/`, {
        username: userID,
        new_password: newPassword,
      });

      if (response.data === 1) {
        navigation.navigate("Login");
      } else if (response.data["error"]) {
        setErrorMessage(response.data["error"]);
      } else {
        setErrorMessage(response.data["message"]);
      }
    } catch (error) {
      console.error("Password Reset failed:", error.message);
      setErrorMessage("Password reset failed. Please try again.");
    }
  };
  const toggleNewPasswordVisibility = () => {
    setShowNewPassword((prevShowNewPassword) => !prevShowNewPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(
      (prevShowConfirmPassword) => !prevShowConfirmPassword
    );
  };
  return (
    <View style={styles.containerf}>
      <View style={styles.container}>
        <Image source={logo} style={styles.logo} />
      </View>
      <Text style={styles.heading}>Reset Password</Text>
      <View style={styles.allSignIn}>
        {errorMessage !== "" && (
          <Text style={styles.errorText}>{errorMessage}</Text>
        )}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="New Password"
            secureTextEntry={!showNewPassword}
            onChangeText={(text) => setNewPassword(text)}
            value={newPassword}
            placeholderTextColor="#808080"
          />
          <TouchableOpacity
            onPress={toggleNewPasswordVisibility}
            style={styles.icon}
          >
            <FontAwesomeIcon
              icon={showNewPassword ? faEyeSlash : faEye}
              size={20}
              color="black"
            />
          </TouchableOpacity>
        </View>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            secureTextEntry={!showConfirmPassword}
            onChangeText={(text) => setConfirmPassword(text)}
            value={confirmPassword}
            placeholderTextColor="#808080"
          />
          <TouchableOpacity
            onPress={toggleConfirmPasswordVisibility}
            style={styles.icon}
          >
            <FontAwesomeIcon
              icon={showConfirmPassword ? faEyeSlash : faEye}
              size={20}
              color="black"
            />
          </TouchableOpacity>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            onPress={handleResetPassword}
            style={styles.confirmButton}
          >
            <Text style={styles.confirmButtonText}>Confirm</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 100,
    backgroundColor: "#1977F3",
    paddingBottom: 15,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    color: "black",
    textAlign: "center",
    marginBottom: 20,
    marginTop: 60,
  },
  allsignIn: {
    borderRadius: 20,
    padding: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderColor: "#808080",
    marginVertical: 10,
    marginHorizontal: 20,
  },
  input: {
    flex: 1,
    height: 40,
    color: "black",
  },
  icon: {
    marginLeft: 10,
  },
  confirmButton: {
    backgroundColor: "#1977F3",
    padding: 15,
    borderRadius: 10,
    width: "60%",
    alignSelf: "center",
    marginTop: 20,
  },
  topbarinput: {
    justifyContent: "center",
    marginHorizontal: 20,
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    padding: 10,
  },
  inputBox: {
    flex: 1,
    color: "#1977F3",
    marginLeft: 10,
    fontSize: 16,
  },
  confirmButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  errorText: {
    color: "red",
    fontSize: 16,
    textAlign: "center",
    marginTop: 10,
  },
});

export default ForgetPassword;
